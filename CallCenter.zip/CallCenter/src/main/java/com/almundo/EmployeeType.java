/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.almundo;

/**
 * Tipos de operadores que pueden existir en el CallCenter (Operador, supervisor y diretor)
 * @author jleon
 */
public enum EmployeeType {
    
    OPERATOR(1),
    
    SUPERVISOR(2),
    
    DIRECTOR(3);
    
    private Integer priority;

    private EmployeeType(Integer priority) {
        this.priority = priority;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }
    
}
