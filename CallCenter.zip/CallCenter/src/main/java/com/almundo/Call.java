/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.almundo;

import java.util.Random;

/**
 * Clase de la llamada recibida por un empleado
 * @author jleon
 */
public class Call {

    private Integer duration;
    private String number;

    /**
     * Inicializar clase Call con número aleatorio entre 5 y 10
     * @param number
     */
    public Call(String number) {
        Random random = new Random();
        this.duration = random.nextInt(6) + 5;
        this.number = number;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }  
    
}
