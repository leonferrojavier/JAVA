/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.almundo;

import java.util.concurrent.PriorityBlockingQueue;

/**
 *
 * @author jleon
 */
public class Main {
    
    private static final int THREADS = 10;
    
    public static void main(String[] args) {
        
        PriorityBlockingQueue<Employee> employees = new PriorityBlockingQueue<>();
        employees.add(new Operator(EmployeeType.OPERATOR, "Juan"));
        employees.add(new Operator(EmployeeType.OPERATOR, "Jose"));
        employees.add(new Operator(EmployeeType.OPERATOR, "Javier"));
        employees.add(new Operator(EmployeeType.OPERATOR, "Alex"));
        employees.add(new Operator(EmployeeType.OPERATOR, "Maria"));
        employees.add(new Operator(EmployeeType.OPERATOR, "Marta"));
        employees.add(new Operator(EmployeeType.OPERATOR, "Pablo"));
        employees.add(new Operator(EmployeeType.OPERATOR, "Felipe"));
        employees.add(new Supervisor(EmployeeType.SUPERVISOR, "David"));
        employees.add(new Supervisor(EmployeeType.SUPERVISOR, "Pedro"));
        employees.add(new Director(EmployeeType.DIRECTOR, "Oscar"));
        
        Dispatcher dispatcher = new Dispatcher(employees, 10);
                
        for (int i = 0; i < THREADS; i++) {
            dispatcher.dispatchCall(new Call(String.valueOf(i + 1)));
        }
        
        dispatcher.closeExecutor(11);
    }
}
