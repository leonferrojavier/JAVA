/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.almundo;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase encargada de la gestión de las llamadas
 *
 * @author jleon
 */
public class Dispatcher {

    private final ExecutorService executorService;
    private PriorityBlockingQueue<Employee> employees;

    public Dispatcher(PriorityBlockingQueue<Employee> employees, int threads) {
        super();
        this.employees = employees;
        this.executorService = Executors.newFixedThreadPool(threads);
    }

    public void dispatchCall(final Call call) {
        try {
            //Tomar empleado de la cola
            final Employee employee = this.employees.take();

            //Ejecutar concurrentemente las llamadas recibidas
            this.executorService.submit(() -> {
                employee.getCall(call);
                //Añadir de nuevo a la cola
                this.employees.add(employee);
            });
        } catch (InterruptedException ex) {
            Logger.getLogger(Dispatcher.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     * Cerrar executor
     * @param time 
     */
    public void closeExecutor(long time) {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(time, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            Logger.getLogger(Dispatcher.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    public PriorityBlockingQueue<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(PriorityBlockingQueue<Employee> employees) {
        this.employees = employees;
    }

    public ExecutorService getExecutorService() {
        return executorService;
    }
}
