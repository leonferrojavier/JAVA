/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.almundo;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jleon
 */
public abstract class Employee implements Comparable<Employee> {

    /**
     * Tipo de empleado
     */
    private EmployeeType employeeType;

    /**
     * Nombre del empleado
     */
    private String name;

    Employee(EmployeeType employeeType, String name) {
        this.employeeType = employeeType;
        this.name = name;
    }

    public EmployeeType getEmployeeType() {
        return employeeType;
    }

    public void setEmployeeType(EmployeeType employeeType) {
        this.employeeType = employeeType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * Recibir llamada y escribir el detalle de la misma
     *
     * @param call
     */
    public void getCall(Call call) {
        try {
            Thread.sleep(call.getDuration() * 1000);
            System.out.println("El (" + this.employeeType + ") -> (" + this.name + ") atendió la llamada #" + call.getNumber() + " durante " + call.getDuration() + " segundos");
        } catch (InterruptedException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public int compareTo(Employee employee) {
        return this.employeeType.getPriority().compareTo(employee.employeeType.getPriority());
    }
}
