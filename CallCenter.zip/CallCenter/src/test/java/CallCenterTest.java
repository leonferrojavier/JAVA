
import com.almundo.Call;
import com.almundo.Director;
import com.almundo.Dispatcher;
import com.almundo.Employee;
import com.almundo.EmployeeType;
import com.almundo.Operator;
import com.almundo.Supervisor;
import java.util.concurrent.PriorityBlockingQueue;

import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author jleon
 */
public class CallCenterTest {

    /**
     * Lista Empleados
     */
    private PriorityBlockingQueue<Employee> employees = new PriorityBlockingQueue<>();

    @Before
    public void initialize() {
        employees.add(new Operator(EmployeeType.OPERATOR, "Juan"));
        employees.add(new Operator(EmployeeType.OPERATOR, "Jose"));
        employees.add(new Operator(EmployeeType.OPERATOR, "Javier"));
        employees.add(new Operator(EmployeeType.OPERATOR, "Alex"));
        employees.add(new Operator(EmployeeType.OPERATOR, "Maria"));
        employees.add(new Operator(EmployeeType.OPERATOR, "Marta"));
        employees.add(new Operator(EmployeeType.OPERATOR, "Pablo"));
        employees.add(new Operator(EmployeeType.OPERATOR, "Felipe"));
        employees.add(new Supervisor(EmployeeType.SUPERVISOR, "David"));
        employees.add(new Supervisor(EmployeeType.SUPERVISOR, "Pedro"));
        employees.add(new Director(EmployeeType.DIRECTOR, "Oscar"));
    }

    /**
     * Recibir 10 llamadas en el CallCenter
     * @throws InterruptedException 
     */
    @Test
    public void testTenCocurrentCalls() throws InterruptedException {
        Dispatcher dispatcher = new Dispatcher(employees, 10);
        for (int i = 0; i < 10; i++) {
            dispatcher.dispatchCall(new Call(String.valueOf(i + 1)));
        }
        dispatcher.closeExecutor(11);
    }

}
